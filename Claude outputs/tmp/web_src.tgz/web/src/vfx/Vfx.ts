/**
 * Combat visual effects, painted on top of the existing CombatScene.
 *
 * Each helper takes a Phaser scene plus screen-space coordinates and
 * spawns short-lived game objects that the engine cleans up via
 * `onComplete: destroy`. Nothing in here mutates combat state — the
 * scene owns dice rolls and HP; we only draw the eye candy.
 *
 * Conventions:
 *   - Coordinates are arena-relative *screen* pixels (the scene already
 *     converts grid (col, row) → centre x/y via tileX / tileY).
 *   - Colours are 0xRRGGBB integers so they pass straight to Phaser.
 *   - Every effect resolves on its own; awaiting them is optional.
 */

// `import type` so this module stays SSR-safe — Next.js prerenders
// PlayHost's static shell on the server, and a runtime `import Phaser
// from "phaser"` touches `navigator` at module load and crashes the
// build. Phaser's value helpers (Math.Distance.Between / Math.Linear)
// are inlined below as vanilla TS so the file no longer needs the
// runtime side of phaser.
import type Phaser from "phaser";

/** Inline `Phaser.Math.Distance.Between` — Euclidean distance. */
function distBetween(x1: number, y1: number, x2: number, y2: number): number {
  return Math.hypot(x2 - x1, y2 - y1);
}

/** Inline `Phaser.Math.Linear` — single-axis lerp from `a` to `b`. */
function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

const TILE = 32;

const COLOURS: Record<string, number> = {
  fire:      0xff7a3a,
  ember:     0xffce5c,
  lightning: 0xa9d4ff,
  arcane:    0xc28bff,
  heal:      0x88ff9c,
  buff:      0xffe48a,
  curse:     0x9d4cff,
  shield:    0x9bcfff,
  miss:      0xbdb38a,
  blood:     0xff4f4f,
  white:     0xffffff,
};

type Pt = { x: number; y: number };

/** Single bright flash on a target body — colour-coded by intent. */
export function flashTarget(
  scene: Phaser.Scene,
  target: Phaser.GameObjects.GameObject & { x: number; y: number },
  color = COLOURS.blood,
): void {
  const halo = scene.add.circle(
    (target as unknown as { x: number }).x,
    (target as unknown as { y: number }).y,
    18, color, 0.6,
  ).setDepth(50);
  scene.tweens.add({
    targets: halo,
    radius: 26, alpha: 0,
    duration: 220,
    onComplete: () => halo.destroy(),
  });
}

/** Brief tint flicker on the caster — telegraphs that they're casting. */
export function castGlow(
  scene: Phaser.Scene,
  caster: Phaser.GameObjects.GameObject & { x: number; y: number },
  color = COLOURS.arcane,
): void {
  const aura = scene.add.circle(
    (caster as unknown as { x: number }).x,
    (caster as unknown as { y: number }).y,
    20, color, 0.45,
  ).setDepth(40);
  scene.tweens.add({
    targets: aura,
    radius: 8, alpha: 0,
    duration: 320,
    onComplete: () => aura.destroy(),
  });
}

/**
 * Aimed projectile travelling from `from` → `to` on a slight arc. Used
 * by Throw, Range, and single-target damage spells. Rotates the dot to
 * face direction of travel for visual punch.
 */
export function projectileLine(
  scene: Phaser.Scene,
  from: Pt, to: Pt,
  color = COLOURS.arcane,
  durationMs = 220,
): Promise<void> {
  return new Promise((resolve) => {
    const dot = scene.add.rectangle(from.x, from.y, 8, 4, color, 1)
      .setDepth(60);
    const angle = Math.atan2(to.y - from.y, to.x - from.x);
    dot.rotation = angle;
    // Arc midpoint: slight upward bow.
    const dist = distBetween(from.x, from.y, to.x, to.y);
    const apex = Math.min(28, dist * 0.18);
    const midX = (from.x + to.x) / 2;
    const midY = (from.y + to.y) / 2 - apex;
    // Two-step tween: from → mid → to. Phaser doesn't ship a native
    // quadratic-bezier tween, so we just chain two.
    scene.tweens.add({
      targets: dot, x: midX, y: midY,
      duration: durationMs / 2,
      onComplete: () => {
        scene.tweens.add({
          targets: dot, x: to.x, y: to.y,
          duration: durationMs / 2,
          onComplete: () => { dot.destroy(); resolve(); },
        });
      },
    });
  });
}

/**
 * Lightning bolt: a jagged poly-line drawn instantly, then faded out.
 * `segments` randomises the kink count for non-determinism between
 * casts.
 */
export function lightningZigzag(
  scene: Phaser.Scene,
  from: Pt, to: Pt,
  segments = 6,
): Promise<void> {
  return new Promise((resolve) => {
    const g = scene.add.graphics().setDepth(70);
    g.lineStyle(3, COLOURS.lightning, 1);
    g.beginPath();
    g.moveTo(from.x, from.y);
    for (let i = 1; i < segments; i++) {
      const t = i / segments;
      const x = lerp(from.x, to.x, t);
      const y = lerp(from.y, to.y, t);
      const jx = (Math.random() - 0.5) * 14;
      const jy = (Math.random() - 0.5) * 14;
      g.lineTo(x + jx, y + jy);
    }
    g.lineTo(to.x, to.y);
    g.strokePath();
    scene.tweens.add({
      targets: g, alpha: 0,
      duration: 280,
      onComplete: () => { g.destroy(); resolve(); },
    });
  });
}

/**
 * Meteor Strike: a blazing mote that falls from high above and to one
 * side of the target, accelerating downward into a fiery impact burst.
 * Unlike the other projectiles it IGNORES the `from` (caster) point —
 * the meteor comes "from the sky," so the descent always starts above
 * the target regardless of where the slinger stands. Pairs with a
 * fiery trail + a radial ember burst on landing.
 *
 * Used for `damage_type: "meteor"` ranged weapons (the Starfall Sling).
 */
export function meteorStrike(
  scene: Phaser.Scene,
  _from: Pt,
  to: Pt,
  color = COLOURS.fire,
  durationMs = 360,
): Promise<void> {
  return new Promise((resolve) => {
    // Begin high above + offset to the side so the arc reads as a
    // falling star, not a flat shot. The offset stays on-screen for
    // the standard arena viewport.
    const start: Pt = { x: to.x + 84, y: to.y - 220 };
    const head = scene.add.circle(start.x, start.y, 6, COLOURS.white, 1).setDepth(71);
    const glow = scene.add.circle(start.x, start.y, 13, color, 0.5).setDepth(70);

    // Fiery tail: ember motes dropped along the descent, each fading
    // in place so the meteor leaves a streak behind it.
    const trailCount = 10;
    const interval = durationMs / trailCount;
    for (let i = 0; i < trailCount; i++) {
      scene.time.delayedCall(i * interval, () => {
        const t = (i + 0.5) / trailCount;
        const sx = lerp(start.x, to.x, t);
        const sy = lerp(start.y, to.y, t);
        const spark = scene.add
          .circle(sx, sy, 3 + Math.random() * 2, i % 2 ? COLOURS.ember : color, 0.85)
          .setDepth(69);
        scene.tweens.add({
          targets: spark,
          alpha: 0,
          radius: 0.5,
          duration: 300,
          onComplete: () => spark.destroy(),
        });
      });
    }

    scene.tweens.add({
      targets: [head, glow],
      x: to.x,
      y: to.y,
      duration: durationMs,
      ease: "Quad.In", // accelerate as it plummets
      onComplete: () => {
        head.destroy();
        glow.destroy();
        // Fiery impact: white flash + expanding ring + ember scatter.
        const flash = scene.add.circle(to.x, to.y, 6, COLOURS.white, 1).setDepth(73);
        const ring = scene.add
          .circle(to.x, to.y, 8, color, 0)
          .setDepth(72)
          .setStrokeStyle(3, color, 0.9);
        scene.tweens.add({
          targets: flash, radius: 20, alpha: 0,
          duration: 240,
          onComplete: () => flash.destroy(),
        });
        scene.tweens.add({
          targets: ring, radius: 34, alpha: 0,
          duration: 320,
          onComplete: () => { ring.destroy(); resolve(); },
        });
        void radialBurst(scene, to, color, COLOURS.ember, 42);
      },
    });
  });
}

/**
 * Magic Dart: a fast arcane orb streaking straight from caster to
 * target with a trail of fading sparkles behind it and a small white
 * impact flash at the endpoint. Distinct from the gentle bowed
 * `projectileLine` so directional dart casts read as "magic missile",
 * not "thrown rock".
 */
export function magicDart(
  scene: Phaser.Scene,
  from: Pt, to: Pt,
  color = COLOURS.arcane,
  durationMs = 240,
): Promise<void> {
  return new Promise((resolve) => {
    const angle = Math.atan2(to.y - from.y, to.x - from.x);
    // Lead orb + soft halo travel together.
    const orb  = scene.add.circle(from.x, from.y, 5, color, 1).setDepth(60);
    const halo = scene.add.circle(from.x, from.y, 11, color, 0.35).setDepth(59);

    // Sparkle trail dropped along the flight path. Phaser tweens'
    // onUpdate fires every frame, but spawning per-frame would be
    // wasteful — sample 8 evenly-spaced points instead.
    const trailCount = 8;
    const interval = durationMs / trailCount;
    for (let i = 0; i < trailCount; i++) {
      scene.time.delayedCall(i * interval, () => {
        const t = (i + 0.5) / trailCount;
        const sx = from.x + (to.x - from.x) * t;
        const sy = from.y + (to.y - from.y) * t;
        const spark = scene.add
          .circle(sx, sy, 2.5 + Math.random(), color, 0.8)
          .setDepth(58);
        scene.tweens.add({
          targets: spark,
          alpha: 0,
          radius: 0.5,
          duration: 320,
          onComplete: () => spark.destroy(),
        });
      });
    }

    scene.tweens.add({
      targets: [orb, halo],
      x: to.x, y: to.y,
      duration: durationMs,
      ease: "Quad.Out",
      onComplete: () => {
        orb.destroy();
        halo.destroy();
        // Bright impact pop — ring + brief white flash.
        const flash = scene.add.circle(to.x, to.y, 4, COLOURS.white, 1).setDepth(62);
        const ring  = scene.add.circle(to.x, to.y, 6, color, 0).setDepth(61)
          .setStrokeStyle(2, color, 0.9);
        scene.tweens.add({
          targets: flash, radius: 14, alpha: 0,
          duration: 220,
          onComplete: () => flash.destroy(),
        });
        scene.tweens.add({
          targets: ring, radius: 22, alpha: 0,
          duration: 280,
          onComplete: () => { ring.destroy(); resolve(); },
        });
        // Suppress unused lint on `angle` while keeping the symbol
        // available if a future tweak wants to rotate the impact.
        void angle;
      },
    });
  });
}

/**
 * Void Orb: a large, glowing, MULTI-COLOURED sphere that streaks from
 * the caster to a single target. Layered shells (dark halo → bright
 * mid → white core) churn through a void palette (violet, magenta,
 * cyan, indigo) as it flies, trailing scattered multi-coloured sparks.
 * On arrival it implodes to a point, then erupts in a white flash, a
 * twin shockwave ring, and a multi-coloured ember scatter — a clearly
 * "ultimate" read, distinct from the fire / arcane projectiles it used
 * to borrow.
 */
export function voidOrb(
  scene: Phaser.Scene,
  from: Pt, to: Pt,
  _color = COLOURS.curse,
  durationMs = 520,
): Promise<void> {
  return new Promise((resolve) => {
    // The orb cycles through these so it reads as "multi-coloured"
    // rather than a single tint.
    const palette = [0x9d4cff, 0xff4cf0, 0x4cc8ff, 0x6a3cff, 0xc28bff, 0x2ad6c8];

    // Layered shells travel together; a timer recolours them.
    const halo  = scene.add.circle(from.x, from.y, 18, palette[2], 0.26).setDepth(59);
    const outer = scene.add.circle(from.x, from.y, 12, palette[0], 0.55).setDepth(60);
    const mid   = scene.add.circle(from.x, from.y, 8,  palette[1], 0.85).setDepth(61);
    const core  = scene.add.circle(from.x, from.y, 4,  COLOURS.white, 1).setDepth(62);
    const shells = [halo, outer, mid, core];

    // Shimmer: rotate the palette across the shells (and breathe the
    // halo) so the orb visibly churns through colours in flight.
    let step = 0;
    const shimmer = scene.time.addEvent({
      delay: 60,
      loop: true,
      callback: () => {
        outer.setFillStyle(palette[step % palette.length], 0.55);
        mid.setFillStyle(palette[(step + 2) % palette.length], 0.85);
        halo.setFillStyle(palette[(step + 4) % palette.length], 0.26);
        halo.setScale(1 + 0.14 * Math.sin(step * 0.8));
        step += 1;
      },
    });

    // Scattered multi-coloured spark trail along the flight path.
    const trailCount = 12;
    const interval = durationMs / trailCount;
    for (let i = 0; i < trailCount; i++) {
      scene.time.delayedCall(i * interval, () => {
        const t = (i + 0.5) / trailCount;
        const sx = lerp(from.x, to.x, t) + (Math.random() - 0.5) * 9;
        const sy = lerp(from.y, to.y, t) + (Math.random() - 0.5) * 9;
        const c = palette[Math.floor(Math.random() * palette.length)];
        const spark = scene.add
          .circle(sx, sy, 2 + Math.random() * 2, c, 0.85)
          .setDepth(58);
        scene.tweens.add({
          targets: spark, alpha: 0, radius: 0.5,
          duration: 360,
          onComplete: () => spark.destroy(),
        });
      });
    }

    scene.tweens.add({
      targets: shells,
      x: to.x, y: to.y,
      duration: durationMs,
      ease: "Quad.In", // accelerate as the void collapses inward
      onComplete: () => {
        shimmer.remove();
        // Implode to a bright point...
        scene.tweens.add({
          targets: shells, radius: 0.5,
          duration: 90,
          onComplete: () => {
            shells.forEach((s) => s.destroy());
            // ...then erupt: white flash + twin multi-coloured rings.
            const flash = scene.add.circle(to.x, to.y, 6, COLOURS.white, 1).setDepth(64);
            scene.tweens.add({
              targets: flash, radius: 26, alpha: 0,
              duration: 240,
              onComplete: () => flash.destroy(),
            });
            [palette[0], palette[2]].forEach((c, idx) => {
              const ring = scene.add
                .circle(to.x, to.y, 8, c, 0)
                .setDepth(63)
                .setStrokeStyle(3, c, 0.9);
              scene.tweens.add({
                targets: ring, radius: 40 + idx * 12, alpha: 0,
                duration: 360 + idx * 90,
                onComplete: () => {
                  ring.destroy();
                  if (idx === 1) resolve();
                },
              });
            });
            void radialBurst(scene, to, palette[1], palette[3], 60);
          },
        });
      },
    });
  });
}

/**
 * Magic Arrow: an elongated glowing shaft with a brighter tip and a
 * sparkle trail. Aimed at a specific target (no arc, fast linear
 * flight) — visually distinct from a regular bow shot so casters
 * reading the arena can tell magic from mundane.
 */
export function magicArrow(
  scene: Phaser.Scene,
  from: Pt, to: Pt,
  color = COLOURS.lightning,
  durationMs = 280,
): Promise<void> {
  return new Promise((resolve) => {
    const angle = Math.atan2(to.y - from.y, to.x - from.x);
    const shaft = scene.add.rectangle(from.x, from.y, 18, 3, color, 1).setDepth(60);
    shaft.rotation = angle;
    const tip = scene.add.circle(from.x, from.y, 3.5, COLOURS.white, 1).setDepth(61);

    const trailCount = 7;
    const interval = durationMs / trailCount;
    for (let i = 0; i < trailCount; i++) {
      scene.time.delayedCall(i * interval, () => {
        const t = (i + 0.5) / trailCount;
        const sx = from.x + (to.x - from.x) * t;
        const sy = from.y + (to.y - from.y) * t;
        const spark = scene.add
          .circle(sx, sy, 2, color, 0.85)
          .setDepth(58);
        scene.tweens.add({
          targets: spark, alpha: 0,
          duration: 360,
          onComplete: () => spark.destroy(),
        });
      });
    }

    scene.tweens.add({
      targets: [shaft, tip],
      x: to.x, y: to.y,
      duration: durationMs,
      ease: "Quad.In",
      onComplete: () => {
        shaft.destroy();
        tip.destroy();
        // Impact: 6 spark fragments fanning outward + a centre flash.
        const sparks = 6;
        for (let i = 0; i < sparks; i++) {
          const a = (i / sparks) * Math.PI * 2;
          const tx = to.x + Math.cos(a) * 14;
          const ty = to.y + Math.sin(a) * 14;
          const frag = scene.add.rectangle(to.x, to.y, 3, 3, COLOURS.white, 1).setDepth(62);
          scene.tweens.add({
            targets: frag, x: tx, y: ty, alpha: 0,
            duration: 280,
            onComplete: () => frag.destroy(),
          });
        }
        scene.time.delayedCall(280, () => resolve());
      },
    });
  });
}

/**
 * Radial burst — used for Fireball / Turn Undead. Paints an expanding
 * filled circle plus a ring of dots that scatter outward.
 */
export function radialBurst(
  scene: Phaser.Scene,
  at: Pt,
  color = COLOURS.fire,
  emberColor = COLOURS.ember,
  radius = 56,
): Promise<void> {
  return new Promise((resolve) => {
    const orb = scene.add.circle(at.x, at.y, 8, color, 0.85).setDepth(55);
    scene.tweens.add({
      targets: orb,
      radius, alpha: 0,
      duration: 380,
      onComplete: () => orb.destroy(),
    });
    const ring = scene.add.circle(at.x, at.y, 4, emberColor, 0).setDepth(56);
    ring.setStrokeStyle(2, emberColor, 1);
    scene.tweens.add({
      targets: ring,
      radius: radius + 8, alpha: 0,
      duration: 480,
      onComplete: () => ring.destroy(),
    });
    // Embers — small dots flying outward.
    const sparks = 10;
    for (let i = 0; i < sparks; i++) {
      const a = (i / sparks) * Math.PI * 2;
      const sx = at.x, sy = at.y;
      const tx = sx + Math.cos(a) * (radius + 6);
      const ty = sy + Math.sin(a) * (radius + 6);
      const dot = scene.add.rectangle(sx, sy, 4, 4, emberColor, 1).setDepth(57);
      scene.tweens.add({
        targets: dot, x: tx, y: ty, alpha: 0,
        duration: 460,
        onComplete: () => dot.destroy(),
      });
    }
    scene.time.delayedCall(480, () => resolve());
  });
}

/**
 * Dragon's-breath cone — a torrent of flame erupting from `from`
 * (the dragon's mouth, in screen px) toward `to` (the victim's
 * cell, also screen px). Three composited layers carry the look:
 *
 *   1. A widening fire CONE — a triangular fan of overlapping
 *      semi-transparent orange/yellow ellipses tracking from
 *      caster to target. Each "tongue" is offset perpendicular
 *      to the breath axis so the silhouette reads as a forked
 *      jet, not a single beam.
 *   2. A STREAM of jittering ember dots travelling along the
 *      cone axis with slight perpendicular wobble — the visual
 *      "fuel" of the breath, persistent over the whole cast so
 *      the eye can't miss it.
 *   3. A fire IMPACT at the target — a quick fireball-style
 *      radial pop using the same VFX_COLOURS.fire / .ember
 *      palette as the explicit `radialBurst` so the impact
 *      reads at parity with caster-fired fireballs.
 *
 * Coordinates are screen pixels (caller resolves grid → px). The
 * returned Promise resolves a beat after the longest cue so a
 * caller can `await` before resolving HP damage or moving on to
 * the next combat action without the breath cutting off mid-flight.
 *
 * `width` defaults to ~1.4 tiles at the target end — wide enough
 * to read as a cone, narrow enough that the dragon isn't drawing
 * fire across half the arena. `durationMs` is the cone's lifetime
 * (the impact + linger add a small tail).
 */
export function breathOfFire(
  scene: Phaser.Scene,
  from: Pt,
  to: Pt,
  opts: { width?: number; durationMs?: number } = {},
): Promise<void> {
  const width = opts.width ?? TILE * 1.4;
  const durationMs = opts.durationMs ?? 520;
  return new Promise((resolve) => {
    const dx = to.x - from.x;
    const dy = to.y - from.y;
    const angle = Math.atan2(dy, dx);
    const dist = Math.hypot(dx, dy);
    // Perpendicular axis — used to fan tongues + jitter embers
    // across the cone's width.
    const px = -Math.sin(angle);
    const py = Math.cos(angle);

    // ── Layer 1: cone tongues ────────────────────────────────────
    // Five overlapping flame "tongues", each a tall ellipse rotated
    // along the breath axis. Tongues spawn at the dragon's mouth
    // anchored to the caster end, scale outward toward the target,
    // and fade as they go. The perpendicular spread grows linearly
    // with travel so the silhouette opens into a proper cone.
    const TONGUES = 5;
    for (let i = 0; i < TONGUES; i++) {
      // Spread offsets fan from -0.5 .. +0.5 of the cone width.
      const spread = (i / (TONGUES - 1) - 0.5) * width;
      const startX = from.x;
      const startY = from.y;
      const endX = to.x + px * spread;
      const endY = to.y + py * spread;
      // Each tongue's body is a thin ellipse — width along the
      // cone axis, height perpendicular. Color alternates between
      // the deep fire orange and the brighter ember yellow so the
      // overlap reads as turbulence rather than a flat fill.
      const colour = i % 2 === 0 ? COLOURS.fire : COLOURS.ember;
      const tongue = scene.add
        .ellipse(startX, startY, 4, 10, colour, 0.85)
        .setDepth(58);
      tongue.rotation = angle;
      scene.tweens.add({
        targets: tongue,
        x: (startX + endX) / 2,
        y: (startY + endY) / 2,
        scaleX: Math.max(2, dist / 14),
        scaleY: 1.6 + Math.random() * 0.6,
        alpha: 0,
        // Stagger each tongue slightly so the breath looks like
        // it's pulsing forward rather than appearing all at once.
        delay: i * 28,
        duration: durationMs,
        ease: "Quad.Out",
        onComplete: () => tongue.destroy(),
      });
    }

    // ── Layer 2: ember stream ────────────────────────────────────
    // Lots of small dots travelling along the cone axis with random
    // perpendicular jitter — the "fuel" of the breath. Spawned at a
    // steady cadence over the breath's lifetime so the cone looks
    // continuously alive rather than a single flash.
    const EMBER_COUNT = 22;
    const interval = durationMs / EMBER_COUNT;
    const emberColors = [COLOURS.fire, COLOURS.ember, COLOURS.white];
    for (let i = 0; i < EMBER_COUNT; i++) {
      scene.time.delayedCall(i * interval * 0.6, () => {
        // Small per-ember randomisation makes the stream feel
        // alive — not every ember reaches the same depth, not
        // every one drifts the same way.
        const travel = 0.4 + Math.random() * 0.6;
        const jitterStart = (Math.random() - 0.5) * (width * 0.18);
        const jitterEnd = (Math.random() - 0.5) * width;
        const sx = from.x + px * jitterStart;
        const sy = from.y + py * jitterStart;
        const ex = from.x + dx * travel + px * jitterEnd;
        const ey = from.y + dy * travel + py * jitterEnd;
        const c = emberColors[i % emberColors.length];
        const dot = scene.add
          .circle(sx, sy, 2 + Math.random() * 1.5, c, 1)
          .setDepth(60);
        scene.tweens.add({
          targets: dot,
          x: ex,
          y: ey,
          alpha: 0,
          radius: 0.5,
          duration: 380 + Math.random() * 240,
          ease: "Cubic.Out",
          onComplete: () => dot.destroy(),
        });
      });
    }

    // ── Layer 3: target impact ───────────────────────────────────
    // Fire the impact ~70% of the way through the cone so it
    // visually "follows" the leading edge of the breath rather
    // than detonating before the flames arrive. radialBurst gives
    // us a fireball-quality pop for free; the tighter radius
    // keeps it inside the target tile.
    const impactDelay = Math.round(durationMs * 0.7);
    scene.time.delayedCall(impactDelay, () => {
      void radialBurst(scene, to, COLOURS.fire, COLOURS.ember, 36);
    });

    // Resolve slightly after the impact + ember tail so an
    // awaiting caller doesn't move on while flames are still
    // visible.
    scene.time.delayedCall(durationMs + 260, () => resolve());
  });
}

/**
 * Rising green sparkles for heal-type spells. Spawns a handful of dots
 * just below the target sprite that float up while fading.
 */
export function healingSparkles(
  scene: Phaser.Scene,
  at: Pt,
  count = 8,
): Promise<void> {
  return new Promise((resolve) => {
    const colors = [COLOURS.heal, 0xb4f5be, 0xeaffe0];
    for (let i = 0; i < count; i++) {
      const ox = (Math.random() - 0.5) * TILE;
      const sx = at.x + ox;
      const sy = at.y + TILE / 2;
      const dot = scene.add.circle(
        sx, sy, 2.5, colors[i % colors.length], 1,
      ).setDepth(55);
      scene.tweens.add({
        targets: dot,
        y: sy - TILE - 8 - Math.random() * 8,
        alpha: 0,
        duration: 700 + Math.random() * 300,
        delay: Math.random() * 120,
        onComplete: () => dot.destroy(),
      });
    }
    scene.time.delayedCall(900, () => resolve());
  });
}

/**
 * Campfire rest — fired when the party uses Camping Supplies on the
 * Party screen. Plays a stack of three cues so the rest reads as
 * something more substantial than a one-shot heal:
 *
 *   1. A warm orange glow pool at the party's feet (slow fade-in
 *      then fade-out, like a settled fire).
 *   2. A couple of flame-shaped "flicker" tongues licking upward
 *      from the centre, slightly off-axis so they read as a fire
 *      rather than a heal sparkle.
 *   3. ~10 ember dots drifting upward and fading — the same idea
 *      as healingSparkles but tinted ember / fire so it doesn't
 *      look like a Cleric heal.
 *
 * Tunable counts default to a comfortable middle setting; tests
 * can pass `embers: 0, flickers: 0` to keep the helper cheap.
 */
export function campfireRest(
  scene: Phaser.Scene,
  at: Pt,
  opts: { embers?: number; flickers?: number } = {},
): Promise<void> {
  const embers = opts.embers ?? 10;
  const flickers = opts.flickers ?? 3;
  return new Promise((resolve) => {
    // 1. Warm pool of light at the party's feet. Fades in over the
    //    first third of the animation, holds briefly, then fades out.
    const pool = scene.add
      .circle(at.x, at.y + TILE * 0.25, TILE * 0.55, COLOURS.fire, 0)
      .setDepth(44);
    scene.tweens.add({
      targets: pool,
      alpha: 0.35,
      duration: 320,
      yoyo: true,
      hold: 380,
      onComplete: () => pool.destroy(),
    });

    // 2. Flame flicker tongues — short vertical ellipses that pop
    //    up off the pool centre and fade as they rise.
    for (let i = 0; i < flickers; i++) {
      const ox = (Math.random() - 0.5) * TILE * 0.4;
      const flame = scene.add
        .ellipse(
          at.x + ox,
          at.y + TILE * 0.15,
          TILE * 0.18,
          TILE * 0.32,
          COLOURS.ember,
          0.85,
        )
        .setDepth(46);
      scene.tweens.add({
        targets: flame,
        y: flame.y - TILE * 0.5,
        scaleX: 0.6,
        scaleY: 1.3,
        alpha: 0,
        duration: 480 + Math.random() * 160,
        delay: 80 + i * 70,
        onComplete: () => flame.destroy(),
      });
    }

    // 3. Rising embers. Same broad idea as healingSparkles but
    //    fire-tinted and lifted a little higher so the eye reads
    //    "smoke + sparks off a fire" rather than "heal sparkles".
    const colors = [COLOURS.ember, COLOURS.fire, 0xfff1c2];
    for (let i = 0; i < embers; i++) {
      const ox = (Math.random() - 0.5) * TILE * 0.7;
      const sx = at.x + ox;
      const sy = at.y + TILE / 3;
      const dot = scene.add
        .circle(sx, sy, 2 + Math.random() * 1.2, colors[i % colors.length], 1)
        .setDepth(55);
      scene.tweens.add({
        targets: dot,
        // Embers drift slightly side-to-side as they rise.
        x: sx + (Math.random() - 0.5) * TILE * 0.5,
        y: sy - TILE * 1.2 - Math.random() * 12,
        alpha: 0,
        duration: 900 + Math.random() * 400,
        delay: 60 + Math.random() * 280,
        onComplete: () => dot.destroy(),
      });
    }

    // Resolve a little after the longest cue so callers awaiting the
    // promise get a clean "rest finished" moment.
    scene.time.delayedCall(1300, () => resolve());
  });
}

/**
 * Item-pickup sparkle — fired when the party walks onto a map cell
 * carrying an item and collects it. A warm golden "collected!" cue
 * composited from three layers, sized to a single tile so it reads
 * as picking something up off the ground:
 *
 *   1. A soft filled glow pool that blooms briefly and fades.
 *   2. An expanding golden ring (the "pop").
 *   3. A handful of gold/ember/white sparkles rising and fading.
 *
 * Coordinates are screen pixels (caller resolves grid → centre px).
 * `depth` lets the caller lift the effect above whatever sits on the
 * tile — on the overworld the party sprite rides high (depth ~300),
 * so the host passes a depth above that; the combat default (60)
 * suits the arena's lower depth band. Non-blocking: the helper owns
 * and cleans up its own objects.
 */
export function itemPickup(
  scene: Phaser.Scene,
  at: Pt,
  opts: { color?: number; depth?: number } = {},
): void {
  const color = opts.color ?? COLOURS.buff;
  const depth = opts.depth ?? 60;

  // 1. Soft glow pool — blooms outward from the tile centre.
  const glow = scene.add
    .circle(at.x, at.y, TILE * 0.28, color, 0.5)
    .setDepth(depth - 1);
  scene.tweens.add({
    targets: glow,
    radius: TILE * 0.6,
    alpha: 0,
    duration: 420,
    ease: "Quad.Out",
    onComplete: () => glow.destroy(),
  });

  // 2. Expanding ring — the "pop".
  const ring = scene.add.circle(at.x, at.y, 6, color, 0).setDepth(depth);
  ring.setStrokeStyle(2, color, 0.9);
  scene.tweens.add({
    targets: ring,
    radius: TILE * 0.9,
    alpha: 0,
    duration: 480,
    ease: "Quad.Out",
    onComplete: () => ring.destroy(),
  });

  // 3. Rising sparkles — gold / ember / white motes drifting up.
  const colors = [COLOURS.buff, COLOURS.ember, COLOURS.white];
  const SPARKS = 8;
  for (let i = 0; i < SPARKS; i++) {
    const ox = (Math.random() - 0.5) * TILE * 0.8;
    const sx = at.x + ox;
    const sy = at.y + (Math.random() - 0.5) * TILE * 0.3;
    const dot = scene.add
      .circle(sx, sy, 1.6 + Math.random() * 1.4, colors[i % colors.length], 1)
      .setDepth(depth + 1);
    scene.tweens.add({
      targets: dot,
      x: sx + (Math.random() - 0.5) * TILE * 0.3,
      y: sy - TILE * 0.9 - Math.random() * 10,
      alpha: 0,
      duration: 600 + Math.random() * 260,
      delay: Math.random() * 120,
      onComplete: () => dot.destroy(),
    });
  }
}

/**
 * Buff aura — slow expanding ring around an ally. Used for Bless,
 * Shield, Long Shanks, Invisibility (slightly different colours per
 * source; caller picks).
 */
export function glowAura(
  scene: Phaser.Scene,
  at: Pt,
  color = COLOURS.buff,
): Promise<void> {
  return new Promise((resolve) => {
    const ring = scene.add.circle(at.x, at.y, 10, color, 0).setDepth(45);
    ring.setStrokeStyle(2, color, 0.9);
    scene.tweens.add({
      targets: ring,
      radius: 28, alpha: 0,
      duration: 520,
      onComplete: () => { ring.destroy(); resolve(); },
    });
  });
}

/** Quick screen shake — used for crits, explosions, big damage. */
export function screenShake(
  scene: Phaser.Scene,
  intensity = 0.005,
  durationMs = 180,
): void {
  if (!scene.cameras?.main) return;
  scene.cameras.main.shake(durationMs, intensity);
}

/** Floating "miss" or "X" marker over a target. Doesn't block. */
export function floatingX(
  scene: Phaser.Scene,
  at: Pt,
): void {
  const t = scene.add.text(at.x, at.y - 4, "✕", {
    fontFamily: "Georgia, serif",
    fontSize: "20px",
    color: "#bdb38a",
    stroke: "#1a1a2e",
    strokeThickness: 3,
  }).setOrigin(0.5).setDepth(80);
  scene.tweens.add({
    targets: t, y: t.y - 16, alpha: 0,
    duration: 480,
    onComplete: () => t.destroy(),
  });
}

/**
 * Item-shatter effect — fired when a piece of equipment hits zero
 * durability and is destroyed. Layers four pieces of feedback so the
 * player can't miss it:
 *
 *   1. A bright radial burst at the wearer's body (orb + ring + sparks).
 *   2. ~10 jagged "fragments" (small rotating rectangles) flying
 *      outward in a ring, slowing and fading like real debris.
 *   3. A floating "<ITEM> SHATTERED!" label that rises and fades.
 *   4. A short camera shake — punchier than a normal crit because the
 *      player just lost a piece of gear.
 *
 * `color` and `accent` let the caller tint by item type (gold/red for
 * weapons, blue/white for armor); both default to fire-ember.
 */
export function shatterEffect(
  scene: Phaser.Scene,
  at: Pt,
  itemName: string,
  color = COLOURS.fire,
  accent = COLOURS.ember,
): void {
  // 1. Underlying burst — re-uses the existing radial-burst helper.
  void radialBurst(scene, at, color, accent, 50);

  // 2. Debris fragments — small rotating rectangles flying outward.
  const FRAGMENTS = 10;
  for (let i = 0; i < FRAGMENTS; i++) {
    const angle = (i / FRAGMENTS) * Math.PI * 2 + (Math.random() - 0.5) * 0.4;
    const dist = 28 + Math.random() * 28;
    const tx = at.x + Math.cos(angle) * dist;
    const ty = at.y + Math.sin(angle) * dist;
    const w = 3 + Math.random() * 3;
    const h = 5 + Math.random() * 4;
    const c = i % 2 === 0 ? color : accent;
    const frag = scene.add.rectangle(at.x, at.y, w, h, c, 1).setDepth(78);
    frag.rotation = Math.random() * Math.PI * 2;
    scene.tweens.add({
      targets: frag,
      x: tx, y: ty,
      rotation: frag.rotation + (Math.random() - 0.5) * 4,
      alpha: 0,
      duration: 520 + Math.random() * 200,
      ease: "Cubic.Out",
      onComplete: () => frag.destroy(),
    });
  }

  // 3. Floating label — rises ~28px while fading.
  const label = scene.add.text(at.x, at.y - 12, `${itemName.toUpperCase()} SHATTERED!`, {
    fontFamily: "Georgia, serif",
    fontSize: "12px",
    color: "#ffe48a",
    stroke: "#1a1a2e",
    strokeThickness: 4,
  }).setOrigin(0.5, 1).setDepth(82);
  scene.tweens.add({
    targets: label,
    y: label.y - 28,
    alpha: 0,
    duration: 900,
    onComplete: () => label.destroy(),
  });

  // 4. Camera shake — short and sharp.
  screenShake(scene, 0.008, 240);
}

/**
 * Party-member death sequence — body slumps + red burst + heavy
 * shake. Returns a Promise that resolves when the body animation
 * finishes (~700ms) so callers can chain the next combat action
 * after a beat.
 *
 * The body's rotation and alpha are mutated permanently so the
 * sprite stays "fallen" for the rest of the encounter (the scene's
 * `refreshVisibility` only touches alpha; rotation sticks). The
 * caller is still expected to dim the body to its dead alpha via
 * the usual visibility refresh — this helper just animates the
 * transition there.
 */
export function partyDeathSlump(
  scene: Phaser.Scene,
  body: Phaser.GameObjects.GameObject & { x: number; y: number; rotation: number; alpha: number },
): Promise<void> {
  // Underlying red burst — feels like a wound spraying outward.
  void radialBurst(scene, { x: body.x, y: body.y }, COLOURS.blood, COLOURS.fire, 36);
  screenShake(scene, 0.012, 360);
  return new Promise((resolve) => {
    scene.tweens.add({
      targets: body,
      // Tilt onto the side and slide down a few pixels — reads as
      // "knocked over" without needing a custom death sprite.
      rotation: Math.PI / 2,
      y: body.y + 8,
      alpha: 0.35,
      duration: 600,
      ease: "Cubic.Out",
      onComplete: () => resolve(),
    });
  });
}

/**
 * Centre-arena banner announcing a party member's death. Big red
 * text with stroke, holds for ~2.4s then fades out over 600ms so
 * the next combat tick can move on. Returns immediately — the
 * banner cleans itself up. Pass arena bounds so the banner sits
 * over the playfield rather than the HUD column.
 */
export function partyDeathBanner(
  scene: Phaser.Scene,
  bounds: { x: number; y: number; width: number; height: number },
  name: string,
): void {
  const cx = bounds.x + bounds.width / 2;
  const cy = bounds.y + bounds.height / 2;
  // Smoky backdrop — slight darkening so the bright red text reads
  // even when the arena tile colour is similarly warm.
  const veil = scene.add
    .rectangle(cx, cy, bounds.width, 80, 0x000000, 0.55)
    .setOrigin(0.5)
    .setDepth(199)
    .setAlpha(0);
  const text = scene.add
    .text(cx, cy, `${name.toUpperCase()} HAS FALLEN!`, {
      fontFamily: "Georgia, serif",
      fontSize: "32px",
      color: "#ff4f4f",
      stroke: "#1a1a2e",
      strokeThickness: 6,
    })
    .setOrigin(0.5)
    .setDepth(200)
    .setAlpha(0);
  // Quick fade-in (180ms) → hold (~2s) → slow fade-out (600ms).
  // Tweening alpha rather than killing the timeline outright keeps
  // the message readable across the transition into the next turn.
  scene.tweens.add({
    targets: [veil, text],
    alpha: 1,
    duration: 180,
    onComplete: () => {
      scene.time.delayedCall(2000, () => {
        scene.tweens.add({
          targets: [veil, text],
          alpha: 0,
          duration: 600,
          onComplete: () => { veil.destroy(); text.destroy(); },
        });
      });
    },
  });
}

export const VFX_COLOURS = COLOURS;
