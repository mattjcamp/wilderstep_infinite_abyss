import { describe, expect, it } from "vitest";

import {
  activeKillStepsAt,
  claimQuestRewards,
  creditQuestDiscover,
  creditQuestKill,
  creditQuestMeet,
  creditQuestClearDungeon,
  creditQuestRetrieve,
  ensureQuestStates,
  expandSpelunkingQuests,
  matchesLocation,
  parseQuestsFile,
  type CombatLocation,
  type QuestState,
} from "./Quests";

describe("parseQuestsFile (v2 envelope)", () => {
  it("parses the v2 `{ quests: [...] }` envelope", () => {
    const raw = {
      quests: [
        {
          id: "rats",
          name: "The Giant Rats",
          description: "Get rid of those giant rats in their giant rat hiole",
          tags: ["rats"],
          steps: [
            {
              id: "rats_step_1",
              name: "Step 1 Kill the Giant Rats",
              kind: "kill",
              params: { encounter_id: "cellar_rats", count: 1 },
              description: "Kill the Giant Rats in the cave under the shop",
              tags: ["rats"],
              location_kind: "map",
              map_id: "demo_map",
            },
          ],
          quest_giver: {
            npc_name: "Jerald",
            npc_sprite: "person/hobbit2.png",
            start_dialog: "Help me!",
            end_dialog: "Thanks!",
          },
          rewards: { xp: 100, gold: 100, items: ["camping_supplies"] },
        },
      ],
    };
    const defs = parseQuestsFile(raw);
    expect(defs).toHaveLength(1);
    const q = defs[0];
    expect(q.id).toBe("rats");
    expect(q.name).toBe("The Giant Rats");
    expect(q.tags).toEqual(["rats"]);
    expect(q.questGiver.npcName).toBe("Jerald");
    expect(q.questGiver.npcSprite).toBe("person/hobbit2.png");
    expect(q.questGiver.startDialog).toBe("Help me!");
    expect(q.questGiver.endDialog).toBe("Thanks!");
    expect(q.rewards).toEqual({
      xp: 100,
      gold: 100,
      items: ["camping_supplies"],
      // tileAdds is the sole tile-mutation reward; defaults to empty
      // when the fixture doesn't author any.
      tileAdds: [],
      travel: null,
    });
    expect(q.steps).toHaveLength(1);
    const s = q.steps[0];
    expect(s.id).toBe("rats_step_1");
    expect(s.name).toBe("Step 1 Kill the Giant Rats");
    expect(s.kind).toBe("kill");
    expect(s.encounterId).toBe("cellar_rats");
    expect(s.count).toBe(1);
    expect(s.locationKind).toBe("map");
    expect(s.mapId).toBe("demo_map");
    expect(s.dungeonId).toBe("");
    expect(s.dungeonLevel).toBeUndefined();
  });

  it("parses a v2 dungeon-kind step", () => {
    const defs = parseQuestsFile({
      quests: [
        {
          id: "rats",
          name: "rats",
          steps: [
            {
              id: "s1",
              name: "Slay them",
              kind: "kill",
              params: { encounter_id: "rat_nest", count: 3 },
              location_kind: "dungeon",
              dungeon_id: "the_hole",
              dungeon_level: 2,
            },
          ],
        },
      ],
    });
    expect(defs).toHaveLength(1);
    const s = defs[0].steps[0];
    expect(s.locationKind).toBe("dungeon");
    expect(s.dungeonId).toBe("the_hole");
    expect(s.dungeonLevel).toBe(2);
    expect(s.encounterId).toBe("rat_nest");
    expect(s.count).toBe(3);
  });

  it("accepts a bare-array shape too (no envelope)", () => {
    const defs = parseQuestsFile([
      { id: "bare", name: "Bare", steps: [] },
    ]);
    expect(defs).toHaveLength(1);
    expect(defs[0].id).toBe("bare");
  });

  it("skips quests with no id and no name", () => {
    const defs = parseQuestsFile({
      quests: [{ description: "no id, no name" }, { id: "ok", name: "Ok" }],
    });
    expect(defs.map((q) => q.id)).toEqual(["ok"]);
  });
});

describe("matchesLocation (v2 structured)", () => {
  const mkStep = (over: Partial<{
    locationKind: "" | "map" | "dungeon";
    mapId: string;
    dungeonId: string;
    dungeonLevel?: number;
  }>) => ({
    id: "",
    name: "",
    description: "",
    tags: [],
    kind: "kill" as const,
    params: {},
    encounterId: "",
    count: 1,
    itemId: "",
    locationKind: over.locationKind ?? "",
    mapId: over.mapId ?? "",
    dungeonId: over.dungeonId ?? "",
    dungeonLevel: over.dungeonLevel,
    col: 0,
    row: 0,
    positions: [],
    rewards: { items: [], returnItems: [], tileAdds: [], travel: null },
  });

  it("empty location_kind matches anywhere", () => {
    const step = mkStep({});
    const onMap: CombatLocation = { kind: "map", mapId: "demo_map" };
    const inDungeon: CombatLocation = {
      kind: "dungeon",
      dungeonId: "the_hole",
      dungeonLevel: 2,
    };
    expect(matchesLocation(step, onMap)).toBe(true);
    expect(matchesLocation(step, inDungeon)).toBe(true);
  });

  it("location_kind: map matches the named map only", () => {
    const step = mkStep({ locationKind: "map", mapId: "demo_map" });
    expect(matchesLocation(step, { kind: "map", mapId: "demo_map" })).toBe(
      true,
    );
    expect(matchesLocation(step, { kind: "map", mapId: "other" })).toBe(false);
    expect(
      matchesLocation(step, { kind: "dungeon", dungeonId: "demo_map" }),
    ).toBe(false);
  });

  it("location_kind: dungeon without dungeon_level matches any floor", () => {
    const step = mkStep({ locationKind: "dungeon", dungeonId: "the_hole" });
    expect(
      matchesLocation(step, {
        kind: "dungeon",
        dungeonId: "the_hole",
        dungeonLevel: 1,
      }),
    ).toBe(true);
    expect(
      matchesLocation(step, {
        kind: "dungeon",
        dungeonId: "the_hole",
        dungeonLevel: 4,
      }),
    ).toBe(true);
    expect(
      matchesLocation(step, { kind: "dungeon", dungeonId: "other" }),
    ).toBe(false);
  });

  it("location_kind: dungeon with dungeon_level pins to that floor", () => {
    const step = mkStep({
      locationKind: "dungeon",
      dungeonId: "the_hole",
      dungeonLevel: 2,
    });
    expect(
      matchesLocation(step, {
        kind: "dungeon",
        dungeonId: "the_hole",
        dungeonLevel: 2,
      }),
    ).toBe(true);
    expect(
      matchesLocation(step, {
        kind: "dungeon",
        dungeonId: "the_hole",
        dungeonLevel: 1,
      }),
    ).toBe(false);
  });
});

describe("activeKillStepsAt", () => {
  /** Helper: parse one v2 quest with a single kill step targeting
   *  `demo_map`, then bootstrap its state via `ensureQuestStates`. */
  function bootstrap(opts?: { count?: number; status?: QuestState["status"] }) {
    const defs = parseQuestsFile({
      quests: [
        {
          id: "rats",
          name: "The Giant Rats",
          steps: [
            {
              id: "rats_step_1",
              name: "Kill the rats",
              kind: "kill",
              params: {
                encounter_id: "cellar_rats",
                count: opts?.count ?? 1,
              },
              location_kind: "map",
              map_id: "demo_map",
            },
          ],
        },
      ],
    });
    const states = new Map<string, QuestState>();
    ensureQuestStates(defs, states);
    if (opts?.status) {
      const s = states.get("rats")!;
      s.status = opts.status;
    }
    return { defs, states };
  }

  const onDemoMap: CombatLocation = { kind: "map", mapId: "demo_map" };
  const elsewhere: CombatLocation = { kind: "map", mapId: "other_map" };

  it("returns nothing while the quest is only available (not accepted)", () => {
    const { defs, states } = bootstrap();
    expect(activeKillStepsAt(defs, states, onDemoMap)).toEqual([]);
  });

  it("returns the step once the quest is active and the location matches", () => {
    const { defs, states } = bootstrap({ status: "active" });
    const rows = activeKillStepsAt(defs, states, onDemoMap);
    expect(rows).toHaveLength(1);
    expect(rows[0].questId).toBe("rats");
    expect(rows[0].stepIdx).toBe(0);
    expect(rows[0].encounterId).toBe("cellar_rats");
    expect(rows[0].remaining).toBe(1);
  });

  it("filters out steps whose location doesn't match", () => {
    const { defs, states } = bootstrap({ status: "active" });
    expect(activeKillStepsAt(defs, states, elsewhere)).toEqual([]);
  });

  it("subtracts prior kill credits from `remaining`", () => {
    const { defs, states } = bootstrap({ count: 3, status: "active" });
    const s = states.get("rats")!;
    s.stepKills[0] = 1;
    const rows = activeKillStepsAt(defs, states, onDemoMap);
    expect(rows[0].remaining).toBe(2);
  });

  it("drops steps whose remaining hit zero (handled by stepProgress already, but defensively)", () => {
    const { defs, states } = bootstrap({ count: 2, status: "active" });
    const s = states.get("rats")!;
    s.stepKills[0] = 2; // all credits used, step about to flip complete
    expect(activeKillStepsAt(defs, states, onDemoMap)).toEqual([]);
  });

  it("drops steps already marked complete in stepProgress", () => {
    const { defs, states } = bootstrap({ status: "active" });
    const s = states.get("rats")!;
    s.stepProgress[0] = true;
    expect(activeKillStepsAt(defs, states, onDemoMap)).toEqual([]);
  });
});

describe("creditQuestKill", () => {
  /** Two-step kill quest — first step needs `firstCount` clearings,
   *  second needs 1. Used to exercise step-completion and
   *  quest-completion separately. */
  function bootstrap(opts?: { firstCount?: number }) {
    const defs = parseQuestsFile({
      quests: [
        {
          id: "rats",
          name: "The Giant Rats",
          steps: [
            {
              id: "s1",
              name: "Kill the rats",
              kind: "kill",
              params: { encounter_id: "cellar_rats", count: opts?.firstCount ?? 1 },
              location_kind: "map",
              map_id: "demo_map",
            },
            {
              id: "s2",
              name: "Kill the rat king",
              kind: "kill",
              params: { encounter_id: "rat_king", count: 1 },
              location_kind: "map",
              map_id: "demo_map",
            },
          ],
        },
      ],
    });
    const states = new Map<string, QuestState>();
    ensureQuestStates(defs, states);
    states.get("rats")!.status = "active";
    return { defs, states };
  }

  it("increments stepKills on the first credit", () => {
    const { defs, states } = bootstrap();
    const credit = creditQuestKill(defs, states, "rats", 0);
    expect(credit).not.toBeNull();
    expect(credit!.killsSoFar).toBe(1);
    expect(states.get("rats")!.stepKills[0]).toBe(1);
  });

  it("flips stepProgress when killsSoFar hits count", () => {
    const { defs, states } = bootstrap({ firstCount: 2 });
    const c1 = creditQuestKill(defs, states, "rats", 0);
    expect(c1!.stepCompleted).toBe(false);
    expect(states.get("rats")!.stepProgress[0]).toBe(false);
    const c2 = creditQuestKill(defs, states, "rats", 0);
    expect(c2!.stepCompleted).toBe(true);
    expect(states.get("rats")!.stepProgress[0]).toBe(true);
  });

  it("does not flip the quest until every step is done", () => {
    const { defs, states } = bootstrap();
    const c1 = creditQuestKill(defs, states, "rats", 0);
    expect(c1!.stepCompleted).toBe(true);
    expect(c1!.questCompleted).toBe(false);
    expect(states.get("rats")!.status).toBe("active");
  });

  it("flips status to completed when the LAST step's count is hit", () => {
    const { defs, states } = bootstrap();
    creditQuestKill(defs, states, "rats", 0);
    const final = creditQuestKill(defs, states, "rats", 1);
    expect(final!.questCompleted).toBe(true);
    expect(states.get("rats")!.status).toBe("completed");
  });

  it("returns null for unknown quest id", () => {
    const { defs, states } = bootstrap();
    expect(creditQuestKill(defs, states, "no_such", 0)).toBeNull();
  });

  it("returns null when the step is already complete", () => {
    const { defs, states } = bootstrap();
    states.get("rats")!.stepProgress[0] = true;
    expect(creditQuestKill(defs, states, "rats", 0)).toBeNull();
  });

  it("returns null when the quest isn't active", () => {
    const { defs, states } = bootstrap();
    states.get("rats")!.status = "available";
    expect(creditQuestKill(defs, states, "rats", 0)).toBeNull();
  });
});

describe("claimQuestRewards", () => {
  /** Single-step kill quest with full rewards. */
  function bootstrap(opts?: {
    xp?: number;
    gold?: number;
    items?: string[];
  }) {
    const defs = parseQuestsFile({
      quests: [
        {
          id: "rats",
          name: "The Giant Rats",
          steps: [
            {
              id: "s1",
              name: "Kill the rats",
              kind: "kill",
              params: { encounter_id: "cellar_rats", count: 1 },
              location_kind: "map",
              map_id: "demo_map",
            },
          ],
          rewards: {
            xp: opts?.xp ?? 100,
            gold: opts?.gold ?? 50,
            items: opts?.items ?? ["camping_supplies"],
          },
        },
      ],
    });
    const states = new Map<string, QuestState>();
    ensureQuestStates(defs, states);
    return { defs, states };
  }

  it("returns null when the quest hasn't been completed yet", () => {
    const { defs, states } = bootstrap();
    // Status is "available".
    expect(claimQuestRewards(defs, states, "rats")).toBeNull();
    // Status is "active".
    states.get("rats")!.status = "active";
    expect(claimQuestRewards(defs, states, "rats")).toBeNull();
  });

  it("grants rewards once when status is completed and flips to turned_in", () => {
    const { defs, states } = bootstrap({ xp: 250, gold: 75, items: ["potion", "scroll"] });
    states.get("rats")!.status = "completed";
    const claim = claimQuestRewards(defs, states, "rats");
    expect(claim).not.toBeNull();
    expect(claim!.questId).toBe("rats");
    expect(claim!.questName).toBe("The Giant Rats");
    expect(claim!.xp).toBe(250);
    expect(claim!.gold).toBe(75);
    expect(claim!.items).toEqual(["potion", "scroll"]);
    expect(states.get("rats")!.status).toBe("turned_in");
  });

  it("is idempotent — second call returns null and doesn't re-grant", () => {
    const { defs, states } = bootstrap();
    states.get("rats")!.status = "completed";
    const first = claimQuestRewards(defs, states, "rats");
    expect(first).not.toBeNull();
    const second = claimQuestRewards(defs, states, "rats");
    expect(second).toBeNull();
    expect(states.get("rats")!.status).toBe("turned_in");
  });

  it("returns null for an unknown quest id", () => {
    const { defs, states } = bootstrap();
    states.get("rats")!.status = "completed";
    expect(claimQuestRewards(defs, states, "no_such")).toBeNull();
  });

  it("handles quests with no rewards declared (defaults to 0/0/[])", () => {
    const defs = parseQuestsFile({
      quests: [
        {
          id: "favor",
          name: "Small Favor",
          steps: [{ id: "s1", name: "step", kind: "kill", params: { encounter_id: "rat", count: 1 } }],
        },
      ],
    });
    const states = new Map<string, QuestState>();
    ensureQuestStates(defs, states);
    states.get("favor")!.status = "completed";
    const claim = claimQuestRewards(defs, states, "favor");
    expect(claim).not.toBeNull();
    expect(claim!.xp).toBe(0);
    expect(claim!.gold).toBe(0);
    expect(claim!.items).toEqual([]);
  });
});

describe("step-level rewards", () => {
  it("parses a step's `rewards` block with items + tile_add", () => {
    const defs = parseQuestsFile({
      quests: [
        {
          id: "amulet",
          name: "Lost Amulet",
          steps: [
            {
              id: "s1",
              name: "Find the stone",
              kind: "retrieve",
              item_id: "river_stone",
              location_kind: "map",
              map_id: "forest_map",
              col: 4,
              row: 5,
              rewards: {
                items: ["lockpick", "torch"],
                tile_add: [
                  { map: "forest_map", col: 14, row: 7, tile_id: "bridge" },
                ],
              },
            },
          ],
        },
      ],
    });
    const step = defs[0].steps[0];
    expect(step.rewards.items).toEqual(["lockpick", "torch"]);
    expect(step.rewards.tileAdds).toEqual([
      { map: "forest_map", col: 14, row: 7, tile_id: "bridge" },
    ]);
  });

  it("defaults to empty rewards when the step omits the block", () => {
    const defs = parseQuestsFile({
      quests: [
        {
          id: "rats",
          name: "rats",
          steps: [
            {
              id: "s1",
              name: "step",
              kind: "kill",
              params: { encounter_id: "rat", count: 1 },
            },
          ],
        },
      ],
    });
    const step = defs[0].steps[0];
    expect(step.rewards).toEqual({
      items: [],
      returnItems: [],
      tileAdds: [],
      travel: null,
    });
  });

  it("parses a step's `return_items` (Return Item feature)", () => {
    const defs = parseQuestsFile({
      quests: [
        {
          id: "vault",
          name: "The Sealed Vault",
          steps: [
            {
              id: "s1",
              name: "Unlock the vault",
              kind: "retrieve",
              item_id: "relic",
              location_kind: "map",
              map_id: "vault_map",
              col: 2,
              row: 2,
              rewards: {
                items: ["relic"],
                return_items: ["master_key", "master_key"],
              },
            },
          ],
        },
      ],
    });
    const step = defs[0].steps[0];
    expect(step.rewards.items).toEqual(["relic"]);
    // Listed twice → two copies reclaimed; order preserved.
    expect(step.rewards.returnItems).toEqual(["master_key", "master_key"]);
  });

  it("defaults `return_items` to [] when the rewards block omits it", () => {
    const defs = parseQuestsFile({
      quests: [
        {
          id: "vault",
          name: "vault",
          steps: [
            {
              id: "s1",
              name: "step",
              kind: "kill",
              params: { encounter_id: "guard", count: 1 },
              rewards: { items: ["torch"] },
            },
          ],
        },
      ],
    });
    expect(defs[0].steps[0].rewards.returnItems).toEqual([]);
  });

  it("drops non-string `return_items` entries on load", () => {
    const defs = parseQuestsFile({
      quests: [
        {
          id: "vault",
          name: "vault",
          steps: [
            {
              id: "s1",
              name: "step",
              kind: "kill",
              params: { encounter_id: "guard", count: 1 },
              rewards: { return_items: ["key", 42, null, "key2"] },
            },
          ],
        },
      ],
    });
    expect(defs[0].steps[0].rewards.returnItems).toEqual(["key", "key2"]);
  });

  it("carries `return_items` through a kill-step credit snapshot", () => {
    const defs = parseQuestsFile({
      quests: [
        {
          id: "vault",
          name: "The Sealed Vault",
          steps: [
            {
              id: "s1",
              name: "Defeat the warden",
              kind: "kill",
              params: { encounter_id: "warden", count: 1 },
              rewards: { return_items: ["master_key"] },
            },
          ],
        },
      ],
    });
    const states = new Map<string, QuestState>();
    ensureQuestStates(defs, states);
    states.get("vault")!.status = "active";
    const credit = creditQuestKill(defs, states, "vault", 0);
    expect(credit).not.toBeNull();
    expect(credit!.stepCompleted).toBe(true);
    expect(credit!.stepRewards).not.toBeNull();
    expect(credit!.stepRewards!.returnItems).toEqual(["master_key"]);
    // Snapshot is a copy — mutating it must not touch the def.
    credit!.stepRewards!.returnItems.push("dagger");
    expect(defs[0].steps[0].rewards.returnItems).toEqual(["master_key"]);
  });

  it("drops malformed tile_add entries on load (bad map id / coords)", () => {
    const defs = parseQuestsFile({
      quests: [
        {
          id: "amulet",
          name: "Lost Amulet",
          steps: [
            {
              id: "s1",
              name: "step",
              kind: "kill",
              params: { encounter_id: "rat", count: 1 },
              rewards: {
                items: [42, "ok_item"], // 42 should drop
                tile_add: [
                  { map: "", col: 1, row: 1, tile_id: "bridge" }, // empty map
                  { map: "ok_map", tile_id: "bridge" }, // missing coords
                  { map: "ok_map", col: 1, row: 1, tile_id: "" }, // empty tile_id
                  { map: "ok_map", col: 3, row: 4, tile_id: "bridge" }, // good
                ],
              },
            },
          ],
        },
      ],
    });
    const step = defs[0].steps[0];
    expect(step.rewards.items).toEqual(["ok_item"]);
    expect(step.rewards.tileAdds).toEqual([
      { map: "ok_map", col: 3, row: 4, tile_id: "bridge" },
    ]);
  });

  it("creditQuestKill returns step rewards only on the credit that completes the step", () => {
    const defs = parseQuestsFile({
      quests: [
        {
          id: "rats",
          name: "Rats",
          steps: [
            {
              id: "s1",
              name: "Kill 2 rats",
              kind: "kill",
              params: { encounter_id: "rat", count: 2 },
              location_kind: "map",
              map_id: "demo",
              rewards: {
                items: ["lockpick"],
                tile_add: [
                  { map: "demo", col: 1, row: 2, tile_id: "bridge" },
                ],
              },
            },
          ],
        },
      ],
    });
    const states = new Map<string, QuestState>();
    ensureQuestStates(defs, states);
    states.get("rats")!.status = "active";
    // First credit: progress 1/2 — step NOT completed → stepRewards null.
    const c1 = creditQuestKill(defs, states, "rats", 0);
    expect(c1!.stepCompleted).toBe(false);
    expect(c1!.stepRewards).toBeNull();
    // Second credit: 2/2 → step completes → stepRewards populated.
    const c2 = creditQuestKill(defs, states, "rats", 0);
    expect(c2!.stepCompleted).toBe(true);
    expect(c2!.stepRewards).not.toBeNull();
    expect(c2!.stepRewards!.items).toEqual(["lockpick"]);
    expect(c2!.stepRewards!.tileAdds).toEqual([
      { map: "demo", col: 1, row: 2, tile_id: "bridge" },
    ]);
  });

  it("snapshot returned by creditQuestKill is detached from the underlying def", () => {
    const defs = parseQuestsFile({
      quests: [
        {
          id: "q",
          name: "q",
          steps: [
            {
              id: "s1",
              name: "step",
              kind: "kill",
              params: { encounter_id: "rat", count: 1 },
              rewards: {
                items: ["torch"],
                tile_add: [{ map: "m", col: 0, row: 0, tile_id: "t" }],
              },
            },
          ],
        },
      ],
    });
    const states = new Map<string, QuestState>();
    ensureQuestStates(defs, states);
    states.get("q")!.status = "active";
    const c = creditQuestKill(defs, states, "q", 0);
    expect(c!.stepRewards).not.toBeNull();
    // Mutate the returned snapshot — the def's rewards must stay intact.
    c!.stepRewards!.items.push("dagger");
    c!.stepRewards!.tileAdds.push({
      map: "x", col: 9, row: 9, tile_id: "y",
    });
    expect(defs[0].steps[0].rewards.items).toEqual(["torch"]);
    expect(defs[0].steps[0].rewards.tileAdds).toEqual([
      { map: "m", col: 0, row: 0, tile_id: "t" },
    ]);
  });

  it("creditQuestRetrieve always returns step rewards on a successful credit", () => {
    const defs = parseQuestsFile({
      quests: [
        {
          id: "amulet",
          name: "Lost Amulet",
          steps: [
            {
              id: "s1",
              name: "Find the stone",
              kind: "retrieve",
              item_id: "river_stone",
              location_kind: "map",
              map_id: "forest",
              col: 3,
              row: 3,
              rewards: {
                items: ["key"],
                tile_add: [
                  { map: "forest", col: 5, row: 5, tile_id: "bridge" },
                ],
              },
            },
          ],
        },
      ],
    });
    const states = new Map<string, QuestState>();
    ensureQuestStates(defs, states);
    states.get("amulet")!.status = "active";
    const credit = creditQuestRetrieve(defs, states, "amulet", 0);
    expect(credit).not.toBeNull();
    expect(credit!.stepCompleted).toBe(true);
    expect(credit!.questCompleted).toBe(true);
    expect(credit!.stepRewards.items).toEqual(["key"]);
    expect(credit!.stepRewards.tileAdds).toEqual([
      { map: "forest", col: 5, row: 5, tile_id: "bridge" },
    ]);
  });

  it("creditQuestDiscover completes the quest and can be claimed in place", () => {
    const defs = parseQuestsFile({
      quests: [
        {
          id: "find_outpost",
          name: "Find the Outpost",
          steps: [
            {
              id: "s1",
              name: "Reach the outpost",
              kind: "discover",
              location_kind: "map",
              map_id: "the_crack",
              col: 7,
              row: 9,
            },
          ],
          rewards: { xp: 250, gold: 50, items: ["torch"] },
        },
      ],
    });
    expect(defs[0].steps[0].kind).toBe("discover");
    const states = new Map<string, QuestState>();
    ensureQuestStates(defs, states);
    states.get("find_outpost")!.status = "active";

    const credit = creditQuestDiscover(defs, states, "find_outpost", 0);
    expect(credit).not.toBeNull();
    expect(credit!.stepCompleted).toBe(true);
    expect(credit!.questCompleted).toBe(true);
    // Completing the only step flips the quest to "completed" so the
    // host can claim rewards in place (no return-to-giver gate).
    expect(states.get("find_outpost")!.status).toBe("completed");
    const claim = claimQuestRewards(defs, states, "find_outpost");
    expect(claim).not.toBeNull();
    expect(claim!.xp).toBe(250);
    expect(claim!.gold).toBe(50);
    expect(claim!.items).toEqual(["torch"]);
    expect(states.get("find_outpost")!.status).toBe("turned_in");
  });

  it("creditQuestDiscover rejects the wrong kind / inactive quest", () => {
    const defs = parseQuestsFile({
      quests: [
        {
          id: "kill_rats",
          name: "Kill Rats",
          steps: [
            { id: "s1", name: "kill", kind: "kill", encounter_id: "rat", count: 1 },
          ],
        },
      ],
    });
    const states = new Map<string, QuestState>();
    ensureQuestStates(defs, states);
    states.get("kill_rats")!.status = "active";
    // Step 0 is a kill step, not discover → null.
    expect(creditQuestDiscover(defs, states, "kill_rats", 0)).toBeNull();
  });

  it("parses authored positions on a kill step", () => {
    const defs = parseQuestsFile({
      quests: [
        {
          id: "rats",
          name: "Rats",
          steps: [
            {
              id: "s1",
              name: "Clear the patrols",
              kind: "kill",
              encounter_id: "rat",
              count: 3,
              location_kind: "map",
              map_id: "sewer",
              positions: [
                { col: 5, row: 12 },
                { col: 8, row: 12 },
                { col: 11, row: 12 },
              ],
            },
          ],
        },
      ],
    });
    const step = defs[0].steps[0];
    expect(step.positions).toEqual([
      { col: 5, row: 12 },
      { col: 8, row: 12 },
      { col: 11, row: 12 },
    ]);
  });

  it("defaults positions to [] and drops malformed entries", () => {
    const defs = parseQuestsFile({
      quests: [
        {
          id: "rats",
          name: "Rats",
          steps: [
            {
              id: "s1",
              name: "step a",
              kind: "kill",
              encounter_id: "rat",
              count: 1,
            },
            {
              id: "s2",
              name: "step b",
              kind: "kill",
              encounter_id: "rat",
              count: 1,
              positions: [
                { col: 1 }, // missing row → drop
                { row: 2 }, // missing col → drop
                "not an object", // not an object → drop
                { col: 3, row: 4 }, // good
              ],
            },
          ],
        },
      ],
    });
    expect(defs[0].steps[0].positions).toEqual([]);
    expect(defs[0].steps[1].positions).toEqual([{ col: 3, row: 4 }]);
  });

  it("activeKillStepsAt drops already-credited positions from its slice", () => {
    const defs = parseQuestsFile({
      quests: [
        {
          id: "rats",
          name: "Rats",
          steps: [
            {
              id: "s1",
              name: "Clear",
              kind: "kill",
              encounter_id: "rat",
              count: 3,
              location_kind: "map",
              map_id: "sewer",
              positions: [
                { col: 1, row: 1 },
                { col: 2, row: 2 },
                { col: 3, row: 3 },
              ],
            },
          ],
        },
      ],
    });
    const states = new Map<string, QuestState>();
    ensureQuestStates(defs, states);
    states.get("rats")!.status = "active";
    // Simulate two of the three already credited.
    states.get("rats")!.stepKills[0] = 2;
    const rows = activeKillStepsAt(defs, states, {
      kind: "map",
      mapId: "sewer",
    });
    expect(rows).toHaveLength(1);
    expect(rows[0].remaining).toBe(1);
    // First two authored positions have already been consumed; only
    // the third remains for the outstanding copy.
    expect(rows[0].positions).toEqual([{ col: 3, row: 3 }]);
  });

  it("creditQuestRetrieve returns an empty step-rewards object when the step authors none", () => {
    const defs = parseQuestsFile({
      quests: [
        {
          id: "amulet",
          name: "Lost Amulet",
          steps: [
            {
              id: "s1",
              name: "Find the stone",
              kind: "retrieve",
              item_id: "river_stone",
              location_kind: "map",
              map_id: "forest",
              col: 3,
              row: 3,
            },
          ],
        },
      ],
    });
    const states = new Map<string, QuestState>();
    ensureQuestStates(defs, states);
    states.get("amulet")!.status = "active";
    const credit = creditQuestRetrieve(defs, states, "amulet", 0);
    expect(credit).not.toBeNull();
    expect(credit!.stepRewards).toEqual({
      items: [],
      returnItems: [],
      tileAdds: [],
      travel: null,
    });
  });
});

describe("expandSpelunkingQuests", () => {
  const dungeons = [
    {
      id: "grotto",
      levels: [
        { name: "Mouth", depth: 1 },
        { name: "Tunnels", depth: 2 },
        { name: "The Deep", depth: 3 },
      ],
    },
    { id: "empty_pit", levels: [] },
  ];

  it("fans a template reach step into one step per floor", () => {
    const quests = [
      {
        id: "spelunk_grotto",
        name: "Spelunk the Grotto",
        steps: [
          {
            id: "descend",
            name: "Descend",
            kind: "reach",
            dungeon_id: "grotto",
          },
        ],
      },
    ];
    const [q] = expandSpelunkingQuests(quests, dungeons);
    expect(q.steps).toHaveLength(3);
    expect(q.steps.map((s) => s.dungeon_level)).toEqual([1, 2, 3]);
    expect(q.steps.map((s) => s.kind)).toEqual(["reach", "reach", "reach"]);
    // Each carries the dungeon id + a dungeon location + a name built
    // from the level's authored name.
    expect(q.steps.every((s) => s.dungeon_id === "grotto")).toBe(true);
    expect(q.steps.every((s) => s.location_kind === "dungeon")).toBe(true);
    expect(q.steps[0].name).toBe("Descend: Mouth");
    expect(q.steps[2].name).toBe("Descend: The Deep");
    // Step ids are made unique per floor.
    expect(new Set(q.steps.map((s) => s.id)).size).toBe(3);
  });

  it("is idempotent — a second pass changes nothing", () => {
    const quests = [
      {
        id: "spelunk_grotto",
        name: "Spelunk the Grotto",
        steps: [{ id: "descend", name: "Descend", kind: "reach", dungeon_id: "grotto" }],
      },
    ];
    const once = expandSpelunkingQuests(quests, dungeons);
    const twice = expandSpelunkingQuests(once, dungeons);
    expect(twice).toEqual(once);
  });

  it("leaves reach steps that already pin a level untouched", () => {
    const quests = [
      {
        id: "q",
        name: "Q",
        steps: [
          {
            id: "floor2",
            name: "Reach floor 2",
            kind: "reach",
            dungeon_id: "grotto",
            dungeon_level: 2,
          },
        ],
      },
    ];
    const [q] = expandSpelunkingQuests(quests, dungeons);
    expect(q.steps).toHaveLength(1);
    expect(q.steps[0].dungeon_level).toBe(2);
  });

  it("leaves non-reach steps and unknown / empty dungeons alone", () => {
    const quests = [
      {
        id: "mixed",
        name: "Mixed",
        steps: [
          { id: "kill", name: "Kill", kind: "kill", encounter_id: "rats" },
          { id: "bad", name: "Bad", kind: "reach", dungeon_id: "nope" },
          { id: "empty", name: "Empty", kind: "reach", dungeon_id: "empty_pit" },
        ],
      },
    ];
    const [q] = expandSpelunkingQuests(quests, dungeons);
    // Nothing expanded — kill is untouched, the two bad templates stay
    // as-is (1 step each) so the author can see the dangling ref.
    expect(q.steps).toHaveLength(3);
    expect(q.steps.map((s) => s.id)).toEqual(["kill", "bad", "empty"]);
  });

  it("does not mutate the input quests", () => {
    const quests = [
      {
        id: "q",
        name: "Q",
        steps: [{ id: "descend", name: "Descend", kind: "reach", dungeon_id: "grotto" }],
      },
    ];
    expandSpelunkingQuests(quests, dungeons);
    expect(quests[0].steps).toHaveLength(1);
  });
});

describe("return_to_giver + meet steps", () => {
  const raw = {
    quests: [
      {
        id: "intro",
        name: "Introductions",
        steps: [
          { id: "intro_1", name: "Meet the smith", kind: "meet", npc_id: "smith", meet_dialog: "So you're the one." },
          { id: "intro_2", name: "Meet the mayor", kind: "meet", npc_id: "mayor" },
        ],
      },
      { id: "errand", name: "Errand", return_to_giver: true, steps: [] },
    ],
  };

  it("return_to_giver defaults to false and parses true", () => {
    const defs = parseQuestsFile(raw);
    expect(defs.find((d) => d.id === "intro")!.returnToGiver).toBe(false);
    expect(defs.find((d) => d.id === "errand")!.returnToGiver).toBe(true);
  });

  it("parses npc_id + meet_dialog on meet steps", () => {
    const step = parseQuestsFile(raw)[0].steps[0];
    expect(step.kind).toBe("meet");
    expect(step.npcId).toBe("smith");
    expect(step.meetDialog).toBe("So you're the one.");
    expect(parseQuestsFile(raw)[0].steps[1].meetDialog).toBe("");
  });

  it("creditQuestMeet credits once and completes on the last step", () => {
    const defs = parseQuestsFile(raw);
    const states = new Map<string, QuestState>();
    ensureQuestStates(defs, states);
    expect(creditQuestMeet(defs, states, "intro", 0)).toBeNull(); // not accepted yet
    states.get("intro")!.status = "active";
    const first = creditQuestMeet(defs, states, "intro", 0);
    expect(first?.questCompleted).toBe(false);
    expect(creditQuestMeet(defs, states, "intro", 0)).toBeNull(); // already done
    const last = creditQuestMeet(defs, states, "intro", 1);
    expect(last?.questCompleted).toBe(true);
    expect(states.get("intro")!.status).toBe("completed");
  });
});

describe("clear_dungeon steps", () => {
  const raw = {
    quests: [
      {
        id: "delve",
        name: "Delver",
        steps: [{ id: "delve_1", name: "Clear any dungeon", kind: "clear_dungeon" }],
      },
      {
        id: "delve3",
        name: "Deep Delver",
        steps: [{ id: "delve3_1", name: "Clear three dungeons", kind: "clear_dungeon", count: 3 }],
      },
    ],
  };

  it("parses the kind and count (default 1)", () => {
    const defs = parseQuestsFile(raw);
    expect(defs[0].steps[0].kind).toBe("clear_dungeon");
    expect(defs[0].steps[0].count).toBe(1);
    expect(defs[1].steps[0].count).toBe(3);
  });

  it("credits once, only while active, and completes the quest", () => {
    const defs = parseQuestsFile(raw);
    const states = new Map<string, QuestState>();
    ensureQuestStates(defs, states);
    expect(creditQuestClearDungeon(defs, states, "delve", 0)).toBeNull(); // not accepted
    states.get("delve")!.status = "active";
    const credit = creditQuestClearDungeon(defs, states, "delve", 0);
    expect(credit?.stepCompleted).toBe(true);
    expect(credit?.questCompleted).toBe(true);
    expect(states.get("delve")!.status).toBe("completed");
    expect(creditQuestClearDungeon(defs, states, "delve", 0)).toBeNull();
  });

  it("needs `count` clears before the step completes", () => {
    const defs = parseQuestsFile(raw);
    const states = new Map<string, QuestState>();
    ensureQuestStates(defs, states);
    states.get("delve3")!.status = "active";
    const c1 = creditQuestClearDungeon(defs, states, "delve3", 0, 0);
    expect(c1).toMatchObject({ clearsSoFar: 1, stepCompleted: false, questCompleted: false });
    const c2 = creditQuestClearDungeon(defs, states, "delve3", 0, 1);
    expect(c2).toMatchObject({ clearsSoFar: 2, stepCompleted: false });
    expect(states.get("delve3")!.status).toBe("active");
    const c3 = creditQuestClearDungeon(defs, states, "delve3", 0, 2);
    expect(c3).toMatchObject({ clearsSoFar: 3, stepCompleted: true, questCompleted: true });
    expect(states.get("delve3")!.status).toBe("completed");
  });

  it("resumes from a persisted tally after reload", () => {
    const defs = parseQuestsFile(raw);
    const states = new Map<string, QuestState>();
    ensureQuestStates(defs, states);
    states.get("delve3")!.status = "active";
    // Fresh in-session state, but the save says 2 already cleared.
    const c = creditQuestClearDungeon(defs, states, "delve3", 0, 2);
    expect(c).toMatchObject({ clearsSoFar: 3, stepCompleted: true });
  });

  it("ignores non-clear_dungeon steps", () => {
    const defs = parseQuestsFile({
      quests: [{ id: "q", name: "Q", steps: [{ id: "s", name: "S", kind: "meet", npc_id: "x" }] }],
    });
    const states = new Map<string, QuestState>();
    ensureQuestStates(defs, states);
    states.get("q")!.status = "active";
    expect(creditQuestClearDungeon(defs, states, "q", 0)).toBeNull();
  });
});

describe("travel rewards", () => {
  function questWith(rewards: unknown, stepRewards?: unknown) {
    return parseQuestsFile({
      quests: [
        {
          id: "chart",
          name: "The Hermit's Chart",
          steps: [
            {
              id: "s1",
              name: "Report back",
              kind: "meet",
              npc_id: "hermit",
              ...(stepRewards !== undefined ? { rewards: stepRewards } : {}),
            },
          ],
          rewards,
        },
      ],
    });
  }

  it("parses a quest-level travel reward", () => {
    const defs = questWith({
      xp: 10,
      travel: {
        map: "sunken_vault",
        col: 4,
        row: "9",
        message: "  Take this chart.  ",
      },
    });
    expect(defs[0].rewards.travel).toEqual({
      map: "sunken_vault",
      col: 4,
      row: 9,
      message: "Take this chart.",
    });
  });

  it("parses a step-level travel reward and defaults message to empty", () => {
    const defs = questWith({}, { travel: { map: "sunken_vault", col: 1, row: 2 } });
    expect(defs[0].steps[0].rewards.travel).toEqual({
      map: "sunken_vault",
      col: 1,
      row: 2,
      message: "",
    });
  });

  it("drops malformed travel blocks instead of crashing", () => {
    for (const bad of [
      null,
      "sunken_vault",
      { col: 1, row: 1 },
      { map: "", col: 1, row: 1 },
      { map: "x", col: "abc", row: 1 },
      { map: "x", col: -1, row: 1 },
    ]) {
      expect(questWith({ travel: bad })[0].rewards.travel).toBeNull();
    }
    expect(questWith({})[0].rewards.travel).toBeNull();
  });

  it("claimQuestRewards carries a copy of the travel reward", () => {
    const defs = questWith({
      travel: { map: "sunken_vault", col: 4, row: 9, message: "Go." },
    });
    const states = new Map<string, QuestState>();
    ensureQuestStates(defs, states);
    states.get("chart")!.status = "completed";
    const claim = claimQuestRewards(defs, states, "chart");
    expect(claim!.travel).toEqual({
      map: "sunken_vault",
      col: 4,
      row: 9,
      message: "Go.",
    });
    // A copy — mutating the claim must not touch the def.
    claim!.travel!.col = 99;
    expect(defs[0].rewards.travel!.col).toBe(4);
  });

  it("claimQuestRewards returns travel: null when none is authored", () => {
    const defs = questWith({ xp: 5 });
    const states = new Map<string, QuestState>();
    ensureQuestStates(defs, states);
    states.get("chart")!.status = "completed";
    expect(claimQuestRewards(defs, states, "chart")!.travel).toBeNull();
  });

  it("a meet credit snapshots the step's travel reward", () => {
    const defs = questWith({}, { travel: { map: "sunken_vault", col: 1, row: 2 } });
    const states = new Map<string, QuestState>();
    ensureQuestStates(defs, states);
    states.get("chart")!.status = "active";
    const credit = creditQuestMeet(defs, states, "chart", 0);
    expect(credit).not.toBeNull();
    expect(credit!.stepRewards.travel).toEqual({
      map: "sunken_vault",
      col: 1,
      row: 2,
      message: "",
    });
  });
});
