import { describe, it, expect } from "vitest";
import {
  initialPartyNavState,
  reducePartyNav,
  ACTION_USE,
  ACTION_SEND,
  ACTION_EXAMINE,
  type PartyNavContext,
  type PartyNavState,
} from "./partyScreenNav";

/** Standard context for the bulk of these tests — 3 effects, 5
 *  stash items, 4 members, every action enabled. Individual cases
 *  override the fields they care about. */
function ctx(over?: Partial<PartyNavContext>): PartyNavContext {
  return {
    effectCount: 3,
    stashCount: 5,
    memberCount: 4,
    canUse: true,
    canSend: true,
    effectAvailable: true,
    ...over,
  };
}

function key(state: PartyNavState, k: string, c: PartyNavContext) {
  return reducePartyNav(state, { kind: "key", key: k }, c);
}

describe("initialPartyNavState", () => {
  it("starts on the effects zone", () => {
    const s = initialPartyNavState(ctx());
    expect(s.zone).toBe("effects");
    expect(s.effectIndex).toBe(0);
    expect(s.stashIndex).toBe(0);
  });

  it("reports -1 stash index when the stash is empty", () => {
    const s = initialPartyNavState(ctx({ stashCount: 0 }));
    expect(s.stashIndex).toBe(-1);
  });

  it("clamps effectIndex when no effects exist", () => {
    const s = initialPartyNavState(ctx({ effectCount: 0 }));
    expect(s.effectIndex).toBe(0); // floor — empty list, doesn't matter
  });
});

describe("Effects zone navigation", () => {
  it("ArrowDown moves to the next effect", () => {
    const s = initialPartyNavState(ctx());
    const r = key(s, "ArrowDown", ctx());
    expect(r.state.effectIndex).toBe(1);
    expect(r.consumed).toBe(true);
  });

  it("ArrowUp at the top of the effects clamps (does not wrap)", () => {
    const s = initialPartyNavState(ctx());
    const r = key(s, "ArrowUp", ctx());
    expect(r.state.zone).toBe("effects");
    expect(r.state.effectIndex).toBe(0);
  });

  it("ArrowDown at the last effect spills into the stash", () => {
    const s = { ...initialPartyNavState(ctx()), effectIndex: 2 };
    const r = key(s, "ArrowDown", ctx());
    expect(r.state.zone).toBe("stash");
    expect(r.state.stashIndex).toBe(0);
    expect(r.consumed).toBe(true);
  });

  it("ArrowDown when the effects list is empty also spills into stash", () => {
    const s = initialPartyNavState(ctx({ effectCount: 0 }));
    const r = key(s, "ArrowDown", ctx({ effectCount: 0 }));
    expect(r.state.zone).toBe("stash");
  });

  it("ArrowDown when both lists are empty stays put", () => {
    const c = ctx({ effectCount: 0, stashCount: 0 });
    const s = initialPartyNavState(c);
    const r = key(s, "ArrowDown", c);
    expect(r.state.zone).toBe("effects");
    expect(r.consumed).toBe(true);
  });

  it("Enter on an effect is a passthrough (the focused button handles it natively)", () => {
    // The reducer deliberately does NOT consume Enter in the
    // effects zone. The component focuses the selected effect's
    // <button> when the cursor lands there, the browser's native
    // "Enter on a focused button dispatches click" behavior fires
    // the row's onClick, which toggles via `toggleActive`.
    //
    // Routing through that one path (instead of also emitting an
    // `effect-toggle` action here) eliminates a class of dispatch
    // bugs where the reducer's preventDefault preempts the native
    // click but the reducer's own callback path fires stale state.
    const s = initialPartyNavState(ctx());
    const r = key(s, "Enter", ctx());
    expect(r.consumed).toBe(false);
    expect(r.action).toEqual({ kind: "none" });
  });

  it("Escape bubbles (close action, not consumed)", () => {
    const s = initialPartyNavState(ctx());
    const r = key(s, "Escape", ctx());
    expect(r.action).toEqual({ kind: "close" });
    expect(r.consumed).toBe(false);
  });

  it("Tab also walks into the stash (a11y path)", () => {
    const s = initialPartyNavState(ctx());
    const r = key(s, "Tab", ctx());
    expect(r.state.zone).toBe("stash");
  });
});

describe("Stash zone navigation", () => {
  function stashState(): PartyNavState {
    return { ...initialPartyNavState(ctx()), zone: "stash" };
  }

  it("ArrowDown moves the stash cursor down", () => {
    const r = key(stashState(), "ArrowDown", ctx());
    expect(r.state.stashIndex).toBe(1);
    expect(r.consumed).toBe(true);
  });

  it("ArrowDown at the last stash row clamps", () => {
    const s = { ...stashState(), stashIndex: 4 };
    const r = key(s, "ArrowDown", ctx());
    expect(r.state.stashIndex).toBe(4);
  });

  it("ArrowUp from the first stash row jumps back to the last effect", () => {
    const r = key(stashState(), "ArrowUp", ctx());
    expect(r.state.zone).toBe("effects");
    expect(r.state.effectIndex).toBe(2); // last effect, not first
  });

  it("ArrowUp from the first stash row when no effects exist clamps stash", () => {
    const c = ctx({ effectCount: 0 });
    const r = key(stashState(), "ArrowUp", c);
    expect(r.state.zone).toBe("stash");
    expect(r.state.stashIndex).toBe(0);
  });

  it("Enter on a usable item emits use and stays in the stash", () => {
    const r = key(stashState(), "Enter", ctx());
    expect(r.action).toEqual({ kind: "use" });
    expect(r.state.zone).toBe("stash");
  });

  it("Enter on a non-usable item toggles examine", () => {
    const r = key(stashState(), "Enter", ctx({ canUse: false }));
    expect(r.action).toEqual({ kind: "examine-toggle" });
    expect(r.state.zone).toBe("stash");
  });

  it("U accelerator emits use without going through the submenu", () => {
    const r = key(stashState(), "u", ctx());
    expect(r.action).toEqual({ kind: "use" });
    expect(r.state.zone).toBe("stash"); // stays put
  });

  it("S accelerator opens send mode directly", () => {
    const r = key(stashState(), "S", ctx());
    expect(r.state.zone).toBe("send");
    expect(r.state.sendIndex).toBe(0);
  });

  it("X accelerator toggles examine", () => {
    const r = key(stashState(), "x", ctx());
    expect(r.action).toEqual({ kind: "examine-toggle" });
  });

  it("U on a non-usable item is a no-op", () => {
    const r = key(stashState(), "u", ctx({ canUse: false }));
    expect(r.action).toEqual({ kind: "none" });
  });
});

describe("Actions submenu", () => {
  function actionsState(actionIndex = ACTION_USE): PartyNavState {
    return { ...initialPartyNavState(ctx()), zone: "actions", actionIndex };
  }

  it("ArrowDown cycles forward through enabled actions", () => {
    const r = key(actionsState(ACTION_USE), "ArrowDown", ctx());
    expect(r.state.actionIndex).toBe(ACTION_SEND);
  });

  it("ArrowDown wraps around at the end", () => {
    const r = key(actionsState(ACTION_EXAMINE), "ArrowDown", ctx());
    expect(r.state.actionIndex).toBe(ACTION_USE);
  });

  it("ArrowUp cycles backward", () => {
    const r = key(actionsState(ACTION_USE), "ArrowUp", ctx());
    expect(r.state.actionIndex).toBe(ACTION_EXAMINE);
  });

  it("ArrowDown skips over a disabled Send", () => {
    const c = ctx({ canSend: false });
    const r = key(actionsState(ACTION_USE), "ArrowDown", c);
    expect(r.state.actionIndex).toBe(ACTION_EXAMINE);
  });

  it("ArrowRight switches to the roster zone (column hop)", () => {
    // Left/Right used to cycle the action submenu, but Up/Down
    // handle that and Left/Right are reserved for column-switching
    // now so the model is consistent across all left-pane zones.
    const r = key(actionsState(ACTION_SEND), "ArrowRight", ctx());
    expect(r.state.zone).toBe("roster");
    expect(r.state.lastLeftZone).toBe("actions");
  });

  it("ArrowLeft pops back to the stash list", () => {
    const r = key(actionsState(ACTION_SEND), "ArrowLeft", ctx());
    expect(r.state.zone).toBe("stash");
  });

  it("Enter on Use emits use and returns to stash", () => {
    const r = key(actionsState(ACTION_USE), "Enter", ctx());
    expect(r.action).toEqual({ kind: "use" });
    expect(r.state.zone).toBe("stash");
  });

  it("Enter on Send opens send mode", () => {
    const r = key(actionsState(ACTION_SEND), "Enter", ctx());
    expect(r.state.zone).toBe("send");
    expect(r.state.sendIndex).toBe(0);
  });

  it("Enter on Examine toggles examine and stays on the submenu", () => {
    const r = key(actionsState(ACTION_EXAMINE), "Enter", ctx());
    expect(r.action).toEqual({ kind: "examine-toggle" });
    expect(r.state.zone).toBe("actions");
  });

  it("Enter on a disabled Use is a no-op (doesn't fire use)", () => {
    const c = ctx({ canUse: false });
    const r = key(actionsState(ACTION_USE), "Enter", c);
    expect(r.action).toEqual({ kind: "none" });
  });

  it("Escape pops back to the stash list", () => {
    const r = key(actionsState(ACTION_SEND), "Escape", ctx());
    expect(r.state.zone).toBe("stash");
    expect(r.consumed).toBe(true);
  });

  it("S accelerator inside actions still opens send mode", () => {
    const r = key(actionsState(ACTION_USE), "s", ctx());
    expect(r.state.zone).toBe("send");
  });
});

describe("Send-to picker", () => {
  function sendState(sendIndex = 0): PartyNavState {
    return { ...initialPartyNavState(ctx()), zone: "send", sendIndex };
  }

  it("ArrowDown advances the roster cursor", () => {
    const r = key(sendState(0), "ArrowDown", ctx());
    expect(r.state.sendIndex).toBe(1);
  });

  it("ArrowDown clamps at the last member", () => {
    const r = key(sendState(3), "ArrowDown", ctx());
    expect(r.state.sendIndex).toBe(3);
  });

  it("ArrowUp clamps at the first member", () => {
    const r = key(sendState(0), "ArrowUp", ctx());
    expect(r.state.sendIndex).toBe(0);
  });

  it("Enter commits the send and returns to the stash zone", () => {
    const r = key(sendState(2), "Enter", ctx());
    expect(r.action).toEqual({ kind: "send", memberIndex: 2 });
    expect(r.state.zone).toBe("stash");
  });

  it("Digit 1..N picks the matching slot directly", () => {
    const r = key(sendState(0), "3", ctx());
    expect(r.action).toEqual({ kind: "send", memberIndex: 2 });
    expect(r.state.zone).toBe("stash");
  });

  it("Digit out of range (e.g. 5 when memberCount=4) is ignored", () => {
    const r = key(sendState(0), "5", ctx());
    expect(r.action).toEqual({ kind: "none" });
    expect(r.consumed).toBe(false);
  });

  it("Escape cancels send and returns to the stash", () => {
    const r = key(sendState(1), "Escape", ctx());
    expect(r.state.zone).toBe("stash");
  });

  it("Empty roster — Enter does nothing", () => {
    const c = ctx({ memberCount: 0 });
    const r = key(sendState(0), "Enter", c);
    expect(r.action).toEqual({ kind: "none" });
  });
});

describe("Roster zone navigation", () => {
  function rosterState(rosterIndex = 0): PartyNavState {
    return {
      ...initialPartyNavState(ctx()),
      zone: "roster",
      rosterIndex,
      lastLeftZone: "effects",
    };
  }

  it("ArrowRight from effects enters the roster + remembers origin", () => {
    const s = initialPartyNavState(ctx());
    const r = key(s, "ArrowRight", ctx());
    expect(r.state.zone).toBe("roster");
    expect(r.state.lastLeftZone).toBe("effects");
    expect(r.consumed).toBe(true);
  });

  it("ArrowRight from stash enters the roster, remembering origin", () => {
    const s = { ...initialPartyNavState(ctx()), zone: "stash" as const };
    const r = key(s, "ArrowRight", ctx());
    expect(r.state.zone).toBe("roster");
    expect(r.state.lastLeftZone).toBe("stash");
  });

  it("ArrowRight from actions enters the roster, remembering origin", () => {
    const s = { ...initialPartyNavState(ctx()), zone: "actions" as const };
    const r = key(s, "ArrowRight", ctx());
    expect(r.state.zone).toBe("roster");
    expect(r.state.lastLeftZone).toBe("actions");
  });

  it("ArrowRight from a left zone with no roster members is a no-op", () => {
    const c = ctx({ memberCount: 0 });
    const r = key(initialPartyNavState(c), "ArrowRight", c);
    expect(r.state.zone).toBe("effects"); // stayed put
  });

  it("ArrowLeft from roster returns to lastLeftZone (effects)", () => {
    const r = key(
      { ...rosterState(0), lastLeftZone: "effects" },
      "ArrowLeft",
      ctx(),
    );
    expect(r.state.zone).toBe("effects");
  });

  it("ArrowLeft from roster returns to lastLeftZone (stash)", () => {
    const r = key(
      { ...rosterState(0), lastLeftZone: "stash" },
      "ArrowLeft",
      ctx(),
    );
    expect(r.state.zone).toBe("stash");
  });

  it("ArrowLeft from roster returns to lastLeftZone (actions)", () => {
    const r = key(
      { ...rosterState(0), lastLeftZone: "actions" },
      "ArrowLeft",
      ctx(),
    );
    expect(r.state.zone).toBe("actions");
  });

  it("ArrowDown advances the roster cursor", () => {
    const r = key(rosterState(0), "ArrowDown", ctx());
    expect(r.state.rosterIndex).toBe(1);
  });

  it("ArrowDown clamps at the last member", () => {
    const r = key(rosterState(3), "ArrowDown", ctx());
    expect(r.state.rosterIndex).toBe(3);
  });

  it("ArrowUp clamps at the first member", () => {
    const r = key(rosterState(0), "ArrowUp", ctx());
    expect(r.state.rosterIndex).toBe(0);
  });

  it("Enter emits roster-drill-in with the focused member index", () => {
    const r = key(rosterState(2), "Enter", ctx());
    expect(r.action).toEqual({ kind: "roster-drill-in", memberIndex: 2 });
    expect(r.consumed).toBe(true);
  });

  it("Enter on an empty roster does nothing", () => {
    const c = ctx({ memberCount: 0 });
    const r = key({ ...rosterState(0), lastLeftZone: "effects" }, "Enter", c);
    expect(r.action).toEqual({ kind: "none" });
  });

  it("Escape bubbles (close action, not consumed) — same as effects", () => {
    const r = key(rosterState(1), "Escape", ctx());
    expect(r.action).toEqual({ kind: "close" });
    expect(r.consumed).toBe(false);
  });

  it("Cursor position survives a round-trip out and back", () => {
    // ArrowRight, move down twice, ArrowLeft, ArrowRight — the
    // rosterIndex should still be 2 the second time we arrive.
    let s = initialPartyNavState(ctx());
    s = key(s, "ArrowRight", ctx()).state;
    s = key(s, "ArrowDown", ctx()).state;
    s = key(s, "ArrowDown", ctx()).state;
    expect(s.rosterIndex).toBe(2);
    s = key(s, "ArrowLeft", ctx()).state;
    expect(s.zone).toBe("effects");
    s = key(s, "ArrowRight", ctx()).state;
    expect(s.zone).toBe("roster");
    expect(s.rosterIndex).toBe(2);
  });
});

describe("Mouse-driven setters", () => {
  it("set-effect parks focus on effects with the given index", () => {
    const s = { ...initialPartyNavState(ctx()), zone: "stash" as const };
    const r = reducePartyNav(s, { kind: "set-effect", index: 2 }, ctx());
    expect(r.state.zone).toBe("effects");
    expect(r.state.effectIndex).toBe(2);
  });

  it("set-stash parks focus on the stash", () => {
    const s = initialPartyNavState(ctx());
    const r = reducePartyNav(s, { kind: "set-stash", index: 3 }, ctx());
    expect(r.state.zone).toBe("stash");
    expect(r.state.stashIndex).toBe(3);
  });

  it("set-stash clamps to the actual stash count", () => {
    const r = reducePartyNav(
      initialPartyNavState(ctx()),
      { kind: "set-stash", index: 99 },
      ctx(),
    );
    expect(r.state.stashIndex).toBe(4); // last valid index
  });

  it("set-action moves focus to actions with the given button", () => {
    const r = reducePartyNav(
      initialPartyNavState(ctx()),
      { kind: "set-action", index: ACTION_EXAMINE },
      ctx(),
    );
    expect(r.state.zone).toBe("actions");
    expect(r.state.actionIndex).toBe(ACTION_EXAMINE);
  });

  it("set-roster parks focus on the roster zone with the given index", () => {
    const r = reducePartyNav(
      initialPartyNavState(ctx()),
      { kind: "set-roster", index: 2 },
      ctx(),
    );
    expect(r.state.zone).toBe("roster");
    expect(r.state.rosterIndex).toBe(2);
  });

  it("set-roster clamps to the actual member count", () => {
    const r = reducePartyNav(
      initialPartyNavState(ctx()),
      { kind: "set-roster", index: 99 },
      ctx(),
    );
    expect(r.state.rosterIndex).toBe(3); // memberCount=4 → last valid is 3
  });

  it("reset returns to a fresh state", () => {
    const s: PartyNavState = {
      zone: "send",
      effectIndex: 1,
      stashIndex: 3,
      actionIndex: ACTION_SEND,
      sendIndex: 2,
      rosterIndex: 2,
      lastLeftZone: "stash",
    };
    const r = reducePartyNav(s, { kind: "reset" }, ctx());
    expect(r.state.zone).toBe("effects");
    expect(r.state.effectIndex).toBe(0);
    expect(r.state.stashIndex).toBe(0);
    expect(r.state.sendIndex).toBe(0);
    expect(r.state.rosterIndex).toBe(0);
    expect(r.state.lastLeftZone).toBe("effects");
  });
});

describe("Index clamping on stale state", () => {
  // The component will keep calling the reducer with the live ctx
  // even if the underlying lists changed between renders. The
  // reducer should silently clamp rather than crash.

  it("clamps stashIndex when the stash shrinks", () => {
    const s = { ...initialPartyNavState(ctx()), zone: "stash" as const, stashIndex: 4 };
    const r = key(s, "ArrowDown", ctx({ stashCount: 2 }));
    // After clamp, stashIndex=1 (last valid), Down stays at 1.
    expect(r.state.stashIndex).toBe(1);
  });

  it("clamps effectIndex when the effects list shrinks", () => {
    const s = { ...initialPartyNavState(ctx()), effectIndex: 2 };
    const r = key(s, "ArrowUp", ctx({ effectCount: 1 }));
    // After clamp, effectIndex=0 (only valid), Up clamps to 0.
    expect(r.state.effectIndex).toBe(0);
  });
});

describe("Equip picker", () => {
  function stashSel(): PartyNavState {
    return { ...initialPartyNavState(ctx()), zone: "stash", stashIndex: 0 };
  }

  it("Enter on equipable gear opens the picker at the start index", () => {
    const r = key(stashSel(), "Enter", ctx({ canEquip: true, equipStartIndex: 2 }));
    expect(r.state.zone).toBe("equip");
    expect(r.state.equipIndex).toBe(2);
    expect(r.action).toEqual({ kind: "none" });
  });

  it("Enter on non-gear still uses the item", () => {
    const r = key(stashSel(), "Enter", ctx({ canEquip: false }));
    expect(r.action).toEqual({ kind: "use" });
  });

  it("Up/Down move the picker cursor, clamped to the roster", () => {
    const s = { ...stashSel(), zone: "equip" as const, equipIndex: 0 };
    expect(key(s, "ArrowUp", ctx()).state.equipIndex).toBe(0);
    const down = key(s, "ArrowDown", ctx());
    expect(down.state.equipIndex).toBe(1);
  });

  it("Enter picks the highlighted member and returns to the stash", () => {
    const s = { ...stashSel(), zone: "equip" as const, equipIndex: 1 };
    const r = key(s, "Enter", ctx());
    expect(r.action).toEqual({ kind: "equip", memberIndex: 1 });
    expect(r.state.zone).toBe("stash");
  });

  it("Number keys pick directly", () => {
    const s = { ...stashSel(), zone: "equip" as const, equipIndex: 0 };
    const r = key(s, "3", ctx());
    expect(r.action).toEqual({ kind: "equip", memberIndex: 2 });
  });

  it("Escape cancels back to the stash without acting", () => {
    const s = { ...stashSel(), zone: "equip" as const, equipIndex: 1 };
    const r = key(s, "Escape", ctx());
    expect(r.state.zone).toBe("stash");
    expect(r.action).toEqual({ kind: "none" });
    expect(r.consumed).toBe(true);
  });
});
